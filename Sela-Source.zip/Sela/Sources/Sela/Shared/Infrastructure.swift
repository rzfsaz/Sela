import AppKit
import Combine
import UserNotifications
#if SWIFT_PACKAGE
import SelaCore
#endif

@MainActor
final class DispatchTicker {
    private var source: DispatchSourceTimer?
    func start(every seconds: TimeInterval = 1, action: @escaping @MainActor () -> Void) {
        stop()
        let timer = DispatchSource.makeTimerSource(queue: .main)
        timer.schedule(deadline: .now() + seconds, repeating: seconds, leeway: .milliseconds(100))
        timer.setEventHandler { MainActor.assumeIsolated { action() } }
        source = timer
        timer.resume()
    }
    func stop() { source?.setEventHandler {}; source?.cancel(); source = nil }
    deinit { source?.cancel() }
}

struct CommandFailure: LocalizedError {
    let message: String
    var errorDescription: String? { message }
}

enum CommandRunner {
    // Fixed executable plus argument array: user input never passes through a shell.
    static func run(_ executable: String, arguments: [String]) async throws -> String {
        try await Task.detached(priority: .utility) {
            let task = Process()
            let pipe = Pipe()
            task.executableURL = URL(fileURLWithPath: executable)
            task.arguments = arguments
            task.standardOutput = pipe
            task.standardError = pipe
            try task.run()
            let timeout = DispatchSource.makeTimerSource(queue: .global(qos: .utility))
            var terminationRequested = false
            timeout.schedule(deadline: .now() + 45, repeating: 2)
            timeout.setEventHandler {
                guard task.isRunning else { return }
                if terminationRequested { kill(task.processIdentifier, SIGKILL) }
                else { terminationRequested = true; task.terminate() }
            }
            timeout.resume()
            defer { timeout.cancel() }
            // Drain concurrently with execution so a full pipe cannot block termination.
            let data = pipe.fileHandleForReading.readDataToEndOfFile()
            task.waitUntilExit()
            let text = String(decoding: data, as: UTF8.self).trimmingCharacters(in: .whitespacesAndNewlines)
            guard task.terminationStatus == 0 else {
                throw CommandFailure(message: text.isEmpty ? "Perintah macOS gagal (\(task.terminationStatus))." : text)
            }
            return text
        }.value
    }
}

@MainActor
final class NotificationService: NSObject, ObservableObject, UNUserNotificationCenterDelegate, PowerWarningDelivery {
    @Published var status = "Notifikasi belum diaktifkan"
    private let center = UNUserNotificationCenter.current()
    private var powerIDs: [String] = UserDefaults.standard.stringArray(forKey: "powerNotificationIDs") ?? []
    var powerCancel: (() -> Void)?
    var powerPostpone: (() -> Void)?
    override init() {
        super.init()
        center.delegate = self
        let cancel = UNNotificationAction(identifier: "cancel", title: "Batalkan timer")
        let postpone = UNNotificationAction(identifier: "postpone", title: "Tunda 10 menit")
        center.setNotificationCategories([UNNotificationCategory(identifier: "power", actions: [postpone, cancel], intentIdentifiers: [])])
        Task { await refresh() }
    }
    func refresh() async {
        let settings = await center.notificationSettings()
        status = settings.authorizationStatus == .authorized ? "Notifikasi aktif" : "Aktifkan notifikasi untuk peringatan"
    }
    @discardableResult func request() async -> Bool {
        do { let granted = try await center.requestAuthorization(options: [.alert, .sound]); await refresh(); return granted }
        catch { status = error.localizedDescription; return false }
    }
    func send(id: String, title: String, body: String, after: TimeInterval = 1, category: String = "") {
        let content = UNMutableNotificationContent()
        content.title = title; content.body = body; content.sound = .default; content.categoryIdentifier = category
        let request = UNNotificationRequest(identifier: id, content: content,
            trigger: UNTimeIntervalNotificationTrigger(timeInterval: max(1, after), repeats: false))
        center.add(request) { error in
            if let error { Task { @MainActor in self.status = error.localizedDescription } }
        }
    }
    func reportPowerFailure(_ detail: String) {
        send(id: "power-error", title: "Aksi daya belum dijalankan", body: detail)
    }
    func clearPower() {
        center.removePendingNotificationRequests(withIdentifiers: powerIDs)
        center.removeDeliveredNotifications(withIdentifiers: powerIDs)
        powerIDs = []
        UserDefaults.standard.removeObject(forKey: "powerNotificationIDs")
    }
    func schedule(_ plan: TimerPlan) {
        clearPower()
        for warning in plan.warningDelays() {
            let id = "power-" + UUID().uuidString
            powerIDs.append(id)
            let content = UNMutableNotificationContent()
            content.title = "\(plan.action.title) dalam \(warning.minutes) menit"
            content.body = "Simpan pekerjaan Anda. Timer dapat dibatalkan atau ditunda dari Sela."
            content.sound = .default; content.categoryIdentifier = "power"
            let request = UNNotificationRequest(identifier: id, content: content,
                trigger: UNTimeIntervalNotificationTrigger(timeInterval: max(1, warning.delay), repeats: false))
            center.add(request) { [weak self] error in
                Task { @MainActor in
                    guard let self else { return }
                    if !self.powerIDs.contains(id) {
                        self.center.removePendingNotificationRequests(withIdentifiers: [id])
                        self.center.removeDeliveredNotifications(withIdentifiers: [id])
                    } else if let error { self.status = error.localizedDescription }
                }
            }
        }
        UserDefaults.standard.set(powerIDs, forKey: "powerNotificationIDs")
    }
    nonisolated func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification,
                                            withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        completionHandler([.banner, .sound])
    }
    nonisolated func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse,
                                            withCompletionHandler completionHandler: @escaping () -> Void) {
        Task { @MainActor in
            if powerIDs.contains(response.notification.request.identifier) {
                if response.actionIdentifier == "cancel" { powerCancel?() }
                if response.actionIdentifier == "postpone" { powerPostpone?() }
            }
            completionHandler()
        }
    }
}

@MainActor
final class UsageHistory: ObservableObject {
    struct Entry: Codable, Identifiable { var id = UUID(); let date: Date; let text: String }
    @Published private(set) var entries: [Entry]
    private let defaults: UserDefaults
    init(defaults: UserDefaults = .standard) {
        self.defaults = defaults
        entries = (defaults.data(forKey: "usageHistory").flatMap { try? JSONDecoder().decode([Entry].self, from: $0) }) ?? [] }
    func record(_ text: String) {
        entries.insert(Entry(date: Date(), text: text), at: 0)
        entries = Array(entries.prefix(40))
        defaults.set(try? JSONEncoder().encode(entries), forKey: "usageHistory")
    }
    func clear() { entries = []; defaults.removeObject(forKey: "usageHistory") }
}
