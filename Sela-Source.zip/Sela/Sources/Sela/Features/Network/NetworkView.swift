import SwiftUI
import Charts
#if SWIFT_PACKAGE
import SelaCore
#endif

struct NetworkView: View {
    @ObservedObject var service: NetworkService
    var body: some View {
        FeatureHeader(title: "Network", subtitle: "Lalu lintas, sekilas saja.")
        HStack(spacing: 32) {
            VStack(alignment: .leading, spacing: 8) {
                Label("Download", systemImage: "arrow.down").font(.caption).foregroundStyle(.secondary)
                Text(DisplayFormat.rate(service.download)).font(.system(size: 22, weight: .medium)).monospacedDigit()
            }
            VStack(alignment: .leading, spacing: 8) {
                Label("Upload", systemImage: "arrow.up").font(.caption).foregroundStyle(.secondary)
                Text(DisplayFormat.rate(service.upload)).font(.system(size: 22, weight: .medium)).monospacedDigit()
            }
        }
        Chart(Array(service.samples.enumerated()), id: \.element.id) { index, sample in
            LineMark(x: .value("Detik", index), y: .value("Byte/detik", sample.down), series: .value("Arah", "Download"))
                .foregroundStyle(Color.accentColor)
            LineMark(x: .value("Detik", index), y: .value("Byte/detik", sample.up), series: .value("Arah", "Upload"))
                .foregroundStyle(Color.secondary).lineStyle(StrokeStyle(lineWidth: 1.5, dash: [4, 3]))
        }.chartXAxis(.hidden).chartYAxis(.hidden).frame(height: 128)
            .accessibilityLabel("Grafik kecepatan jaringan 40 detik terakhir")
        HStack { Label("Download", systemImage: "minus").foregroundStyle(Color.accentColor); Label("Upload", systemImage: "ellipsis").foregroundStyle(.secondary) }.font(.caption)
        Toggle("Tampilkan di menu bar", isOn: $service.showInMenuBar).toggleStyle(.switch).controlSize(.small)
        InfoText("Pembaruan setiap detik · \(service.interfaceLabel)\nTotal antarmuka fisik en*. Tunnel VPN dan loopback tidak dihitung ulang. Nilai ini lalu lintas aktual, bukan hasil speed test.")
    }
}
