import Foundation
import Combine
import Darwin
#if SWIFT_PACKAGE
import SelaCore
#endif

@MainActor
final class NetworkService: ObservableObject {
    struct Sample: Identifiable { let id = UUID(); let down: Double; let up: Double }
    @Published private(set) var download: Double = 0
    @Published private(set) var upload: Double = 0
    @Published private(set) var samples: [Sample] = []
    @Published private(set) var interfaceLabel = "Tidak terhubung"
    @Published var showInMenuBar = UserDefaults.standard.bool(forKey: "networkInMenuBar") {
        didSet { UserDefaults.standard.set(showInMenuBar, forKey: "networkInMenuBar") }
    }
    private let ticker = DispatchTicker()
    private var previous: [String: NetworkCounters] = [:]
    private var lastTime = ProcessInfo.processInfo.systemUptime
    init() { sample(); ticker.start { [weak self] in self?.sample() } }
    private func sample() {
        var addresses: UnsafeMutablePointer<ifaddrs>?
        guard getifaddrs(&addresses) == 0 else { return }
        defer { freeifaddrs(addresses) }
        var current: [String: NetworkCounters] = [:]
        var cursor = addresses
        while let pointer = cursor {
            defer { cursor = pointer.pointee.ifa_next }
            let entry = pointer.pointee
            guard let address = entry.ifa_addr, Int32(address.pointee.sa_family) == AF_LINK,
                  entry.ifa_flags & UInt32(IFF_UP) != 0, let raw = entry.ifa_data else { continue }
            let name = String(cString: entry.ifa_name)
            // Physical en interfaces only; avoid VPN/bridge virtual counters double-counting traffic.
            guard name.hasPrefix("en") else { continue }
            let data = raw.assumingMemoryBound(to: if_data.self).pointee
            current[name] = NetworkCounters(received: UInt64(data.ifi_ibytes), sent: UInt64(data.ifi_obytes))
        }
        let now = ProcessInfo.processInfo.systemUptime
        var down = 0.0, up = 0.0
        for (name, counters) in current {
            if let old = previous[name] {
                let rates = counters.rates(since: old, elapsed: now - lastTime)
                down += rates.download; up += rates.upload
            }
        }
        previous = current; lastTime = now
        download = down; upload = up; interfaceLabel = current.keys.sorted().joined(separator: ", ")
        if current.isEmpty { interfaceLabel = "Tidak terhubung" }
        samples.append(Sample(down: down, up: up)); samples = Array(samples.suffix(40))
    }
}
