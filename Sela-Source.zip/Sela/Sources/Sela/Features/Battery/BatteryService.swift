import Foundation
import Combine
import IOKit
import IOKit.ps

@MainActor
final class BatteryService: ObservableObject {
    @Published private(set) var available = false
    @Published private(set) var charge: Int?
    @Published private(set) var health: Int?
    @Published private(set) var cycles: Int?
    @Published private(set) var condition = "Tidak tersedia"
    @Published private(set) var pluggedIn = false
    @Published private(set) var timeRemaining: Int?
    @Published var alertEnabled = UserDefaults.standard.bool(forKey: "batteryAlert") {
        didSet { UserDefaults.standard.set(alertEnabled, forKey: "batteryAlert"); if !alertEnabled { fullSince = nil; alerted = false } }
    }
    private let ticker = DispatchTicker()
    private let notifications: NotificationService
    private var fullSince: Date?
    private var alerted = false
    init(notifications: NotificationService) {
        self.notifications = notifications
        refresh(); ticker.start(every: 60) { [weak self] in self?.refresh() }
    }
    func refresh() {
        available = false; charge = nil; health = nil; cycles = nil; timeRemaining = nil
        pluggedIn = false; condition = "Tidak tersedia"
        if let blob = IOPSCopyPowerSourcesInfo()?.takeRetainedValue(),
           let sources = IOPSCopyPowerSourcesList(blob)?.takeRetainedValue() as? [CFTypeRef] {
            for source in sources {
                guard let data = IOPSGetPowerSourceDescription(blob, source)?.takeUnretainedValue() as? [String: Any],
                      data[kIOPSTypeKey] as? String == kIOPSInternalBatteryType else { continue }
                available = true
                let current = (data[kIOPSCurrentCapacityKey] as? NSNumber)?.doubleValue
                let maximum = (data[kIOPSMaxCapacityKey] as? NSNumber)?.doubleValue
                if let current, let maximum, maximum > 0 { charge = min(100, max(0, Int(current / maximum * 100))) }
                pluggedIn = data[kIOPSPowerSourceStateKey] as? String == kIOPSACPowerValue
                if let minutes = (data[kIOPSTimeToEmptyKey] as? NSNumber)?.intValue, minutes > 0, !pluggedIn {
                    timeRemaining = minutes
                }
                if let healthString = data[kIOPSBatteryHealthKey] as? String {
                    condition = healthString == "Good" ? "Normal" : "Service · \(healthString)"
                }
                break
            }
        }
        let service = IOServiceGetMatchingService(kIOMainPortDefault, IOServiceMatching("AppleSmartBattery"))
        if service != 0 {
            defer { IOObjectRelease(service) }
            var properties: Unmanaged<CFMutableDictionary>?
            if IORegistryEntryCreateCFProperties(service, &properties, kCFAllocatorDefault, 0) == KERN_SUCCESS,
               let values = properties?.takeRetainedValue() as? [String: Any] {
                cycles = (values["CycleCount"] as? NSNumber)?.intValue
                // Registry fields vary by hardware. Never treat a normalized 0–100 charge value as mAh.
                let design = (values["DesignCapacity"] as? NSNumber)?.doubleValue
                let maximum = (values["AppleRawMaxCapacity"] as? NSNumber)?.doubleValue
                    ?? (values["NominalChargeCapacity"] as? NSNumber)?.doubleValue
                if let design, let maximum, design > 100, maximum > 100 {
                    health = min(100, max(0, Int((maximum / design * 100).rounded())))
                }
                if values["PermanentFailureStatus"] as? Int ?? 0 > 0 { condition = "Service" }
            }
        }
        if alertEnabled, pluggedIn, charge == 100 {
            if fullSince == nil { fullSince = Date() }
            if !alerted, let fullSince, Date().timeIntervalSince(fullSince) >= 7200 {
                alerted = true
                notifications.send(id: "battery-full", title: "Baterai sudah penuh", body: "Mac tersambung daya pada 100% selama sekitar 2 jam. Ini pengingat opsional, bukan diagnosis kesehatan baterai.")
            }
        } else { fullSince = nil; alerted = false }
    }
}
