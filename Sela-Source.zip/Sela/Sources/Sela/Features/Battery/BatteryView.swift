import SwiftUI

struct BatteryView: View {
    @ObservedObject var service: BatteryService
    @ObservedObject var notifications: NotificationService
    var body: some View {
        FeatureHeader(title: "Battery Health", subtitle: "Kenali energi Mac Anda.")
        if service.available {
            HStack(alignment: .firstTextBaseline, spacing: 8) {
                Text(service.charge.map { "\($0)%" } ?? "—").font(.system(size: 48, weight: .light))
                Text(service.pluggedIn ? "tersambung daya" : "menggunakan baterai").font(.caption).foregroundStyle(.secondary)
            }
            Surface {
                MetricRow(title: "Kesehatan · estimasi", value: service.health.map { "\($0)%" } ?? "Tidak tersedia")
                Divider()
                MetricRow(title: "Cycle count", value: service.cycles.map(String.init) ?? "Tidak tersedia")
                MetricRow(title: "Kondisi", value: service.condition)
                MetricRow(title: "Sisa waktu", value: service.pluggedIn ? "Daya eksternal" : service.timeRemaining.map { "\($0 / 60)j \($0 % 60)m" } ?? "Menghitung…")
            }
            Toggle("Ingatkan setelah 2 jam di 100%", isOn: $service.alertEnabled).toggleStyle(.switch).controlSize(.small)
                .onChange(of: service.alertEnabled) { _, enabled in if enabled { Task { await notifications.request() } } }
            InfoText("Persentase kesehatan berasal dari kapasitas IOKit dan dapat berbeda dari Settings. Pengingat hanya berjalan selama Sela aktif; tidak mengatur batas pengisian.")
        } else {
            ContentUnavailableView("Tidak ada baterai internal", systemImage: "desktopcomputer", description: Text("Data baterai tersedia di MacBook yang mendukungnya."))
        }
        Button("Perbarui", systemImage: "arrow.clockwise") { service.refresh() }.font(.caption)
    }
}
