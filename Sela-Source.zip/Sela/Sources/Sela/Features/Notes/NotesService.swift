import Foundation
import Combine

@MainActor
final class NotesService: ObservableObject {
    @Published var text: String { didSet { UserDefaults.standard.set(text, forKey: "quickNote"); savedAt = Date() } }
    @Published private(set) var savedAt: Date?
    init() { text = UserDefaults.standard.string(forKey: "quickNote") ?? "" }
}
