import SwiftUI

struct NotesView: View {
    @ObservedObject var service: NotesService
    var body: some View {
        FeatureHeader(title: "Quick Notes", subtitle: "Tangkap pikiran sebelum berlalu.")
        ZStack(alignment: .topLeading) {
            TextEditor(text: $service.text).font(.system(size: 14)).scrollContentBackground(.hidden)
                .padding(8).frame(minHeight: 296).accessibilityLabel("Catatan cepat")
            if service.text.isEmpty { Text("Satu hal yang ingin Anda ingat…").foregroundStyle(.tertiary).padding(13).allowsHitTesting(false) }
        }.background(.primary.opacity(0.03), in: RoundedRectangle(cornerRadius: 8))
        HStack {
            Label("Tersimpan otomatis di Mac ini", systemImage: "checkmark.circle").font(.caption).foregroundStyle(.secondary)
            Spacer(); Text("\(service.text.count)").font(.caption2).foregroundStyle(.tertiary)
        }
    }
}
