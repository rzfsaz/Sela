import Foundation
import Combine
#if SWIFT_PACKAGE
import SelaCore
#endif

@MainActor
final class CleanerService: ObservableObject {
    @Published private(set) var preview = CleanPreview()
    @Published private(set) var busy = false
    @Published private(set) var scanned = false
    @Published private(set) var result: CleanResult?
    @Published var selected: Set<CleanCategory> = [.caches, .logs]
    var selectedFiles: [CleanCandidate] { preview.files.filter { selected.contains($0.category) } }
    var selectedBytes: Int64 { selectedFiles.reduce(0) { $0 + $1.bytes } }
    func scan() {
        guard !busy else { return }; busy = true; result = nil
        let home = FileManager.default.homeDirectoryForCurrentUser
        let roots: [(CleanCategory, URL)] = [(.caches, home.appendingPathComponent("Library/Caches")),
            (.logs, home.appendingPathComponent("Library/Logs")), (.trash, home.appendingPathComponent(".Trash"))]
        Task {
            preview = await Task.detached(priority: .utility) { SafeCleaner.scan(roots: roots) }.value
            scanned = true; busy = false
        }
    }
    func deletePreviewedFiles() {
        guard !busy, scanned, !selectedFiles.isEmpty else { return }
        let snapshot = selectedFiles
        busy = true
        Task {
            result = await Task.detached(priority: .utility) { SafeCleaner.delete(snapshot) }.value
            // Invalidate the preview even when individual files were skipped.
            preview = CleanPreview(); scanned = false; busy = false
        }
    }
}
