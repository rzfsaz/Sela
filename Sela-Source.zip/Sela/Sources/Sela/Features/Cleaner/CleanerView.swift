import SwiftUI
#if SWIFT_PACKAGE
import SelaCore
#endif

struct CleanerView: View {
    @ObservedObject var service: CleanerService
    @State private var confirming = false
    @State private var showingFiles = false
    var body: some View {
        FeatureHeader(title: "Quick Cleaner", subtitle: "Tinjau dulu. Rapikan kemudian.")
        InfoText("Cache dan log pribadi yang tidak berubah selama 7 hari. Trash opsional. Folder sistem, symlink, dan file yang berubah setelah preview dilewati.")
        if service.busy { ProgressView("Sedang memproses…").controlSize(.small) }
        if let result = service.result {
            Surface {
                Text(DisplayFormat.bytes(result.freed)).font(.system(size: 32, weight: .light))
                Text("\(result.deleted) file dihapus · \(result.skipped) dilewati").font(.caption)
                InfoText("Ukuran alokasi file yang dihapus. Ruang kosong aktual dapat berbeda karena APFS dan snapshot.")
            }
        }
        if service.scanned {
            Surface {
                ForEach(CleanCategory.allCases) { category in
                    Toggle(isOn: Binding(get: { service.selected.contains(category) }, set: { enabled in
                        if enabled { service.selected.insert(category) } else { service.selected.remove(category) }
                    })) {
                        HStack { Text(category.title); Spacer(); Text(DisplayFormat.bytes(service.preview.files.filter { $0.category == category }.reduce(0) { $0 + $1.bytes })).foregroundStyle(.secondary) }
                    }.toggleStyle(.checkbox)
                }
            }
            DisclosureGroup("Preview \(service.selectedFiles.count) file", isExpanded: $showingFiles) {
                ScrollView {
                    LazyVStack(alignment: .leading, spacing: 8) {
                        ForEach(service.selectedFiles) { file in
                            HStack(alignment: .top) {
                                Text(file.url.path.replacingOccurrences(of: FileManager.default.homeDirectoryForCurrentUser.path, with: "~"))
                                    .font(.caption2).lineLimit(2).help(file.url.path)
                                Spacer(); Text(DisplayFormat.bytes(file.bytes)).font(.caption2).foregroundStyle(.secondary)
                            }
                        }
                    }.padding(.top, 8)
                }.frame(height: 120)
            }
            ForEach(service.preview.warnings, id: \.self) { InfoText($0) }
            Button("Hapus \(DisplayFormat.bytes(service.selectedBytes))…", role: .destructive) { confirming = true }
                .disabled(service.selectedFiles.isEmpty || service.busy)
        }
        Button(service.scanned ? "Pindai ulang" : "Preview file", systemImage: "magnifyingglass") { service.scan() }
            .buttonStyle(.borderedProminent).disabled(service.busy)
        .alert("Hapus permanen \(service.selectedFiles.count) file?", isPresented: $confirming) {
            Button("Batal", role: .cancel) {}
            Button("Hapus permanen", role: .destructive) { service.deletePreviewedFiles() }
        } message: { Text("Hanya file yang dipilih dari preview ini yang dihapus. Tindakan ini tidak dapat diurungkan. Tutup aplikasi terkait sebelum membersihkan cache atau log.") }
    }
}
