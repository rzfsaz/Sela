import SwiftUI
#if SWIFT_PACKAGE
import SelaCore
#endif

struct PowerTimerView: View {
    @ObservedObject var service: PowerTimerService
    @ObservedObject var notifications: NotificationService
    @State private var action: PowerAction = .sleep
    @State private var minutes = 30
    @State private var custom = false
    @State private var customHours = 0
    @State private var customMinutes = 45
    private var seconds: TimeInterval { Double(custom ? max(1, customHours * 60 + customMinutes) * 60 : minutes * 60) }
    var body: some View {
        FeatureHeader(title: "Power Timer", subtitle: "Mac Anda, sesuai waktunya.")
        if let plan = service.plan {
            VStack(alignment: .leading, spacing: 16) {
                Label("\(plan.action.title) terjadwal", systemImage: plan.action.symbol).foregroundStyle(.secondary)
                Text(DisplayFormat.countdown(service.remaining)).font(.system(size: 48, weight: .light, design: .rounded))
                    .monospacedDigit().contentTransition(.numericText(countsDown: true))
                ProgressView(value: min(1, max(0, 1 - service.remaining / plan.duration))).tint(.accentColor)
                Text("Pukul \(plan.deadline.formatted(date: .omitted, time: .shortened))").font(.callout).foregroundStyle(.secondary)
                HStack {
                    Button("Tunda 10 menit", systemImage: "plus") { service.postpone() }.buttonStyle(.borderedProminent)
                    Button("Cancel", role: .cancel) { service.cancel() }
                }
            }
            Divider()
            InfoText("Timer tetap berjalan saat panel ditutup. Keluar dari Sela membatalkan timer. Peringatan 5 dan 1 menit mengikuti izin notifikasi.")
        } else if let draft = service.draft {
            VStack(alignment: .leading, spacing: 16) {
                Label("Konfirmasi timer", systemImage: draft.action.symbol).font(.headline)
                Text("\(draft.action.title) dalam \(Int(draft.seconds / 60)) menit")
                    .font(.title2).fontWeight(.medium)
                InfoText("Countdown dimulai setelah Anda menekan Mulai timer. Simpan pekerjaan sebelum waktu habis.")
                HStack(spacing: 12) {
                    Button("Mulai timer") { service.confirmDraft() }
                        .buttonStyle(.borderedProminent).controlSize(.large)
                    Button("Kembali") { service.discardDraft() }
                }
            }
        } else {
            VStack(alignment: .leading, spacing: 16) {
                Picker("Aksi", selection: $action) {
                    ForEach(PowerAction.allCases) { item in Text(item.title).tag(item) }
                }.pickerStyle(.segmented).labelsHidden()
                Text("Mulai dalam").font(.headline).padding(.top, 8)
                HStack(spacing: 8) {
                    ForEach([15, 30, 60, 90], id: \.self) { value in
                        Button { minutes = value; custom = false } label: {
                            Text("\(value)m").frame(maxWidth: .infinity).padding(.vertical, 8)
                        }.buttonStyle(.bordered).tint(!custom && minutes == value ? .accentColor : .secondary)
                    }
                }
                Toggle("Durasi khusus", isOn: $custom).toggleStyle(.switch).controlSize(.small)
                if custom {
                    HStack {
                        Picker("Jam", selection: $customHours) { ForEach(0..<24, id: \.self) { Text("\($0) jam").tag($0) } }
                        Picker("Menit", selection: $customMinutes) { ForEach(0..<60, id: \.self) { Text("\($0) mnt").tag($0) } }
                    }.labelsHidden()
                }
                Button { service.prepare(action: action, seconds: seconds) } label: {
                    Text("Jadwalkan \(action.title)").frame(maxWidth: .infinity)
                }.buttonStyle(.borderedProminent).controlSize(.large)
                    .disabled(service.executing || (custom && customHours == 0 && customMinutes == 0))
            }
            InfoText("Mac harus tetap terjaga untuk menjalankan timer tepat waktu. Shutdown, restart, dan log out dapat tertahan oleh pekerjaan yang belum disimpan.")
        }
        if service.executing { ProgressView("Mengirim aksi ke macOS…").controlSize(.small) }
        if let message = service.message { InfoText(message) }
        VStack(alignment: .leading, spacing: 8) {
            Text(notifications.status).font(.caption).foregroundStyle(.secondary)
            Button("Aktifkan peringatan") {
                Task {
                    if await notifications.request() { service.refreshWarnings() }
                }
            }.font(.caption)
            DisclosureGroup("Akses Sleep / Shutdown") {
                VStack(alignment: .leading, spacing: 8) {
                    InfoText(service.accessMessage ?? "Izinkan Sela mengontrol System Events agar macOS dapat menjalankan aksi daya. Pemeriksaan ini tidak membuat Mac sleep atau shutdown.")
                    Button(service.checkingAccess ? "Memeriksa akses…" : "Periksa akses macOS") {
                        Task { await service.checkAccess() }
                    }.disabled(service.checkingAccess)
                    Button("Buka pengaturan Automation") {
                        NSWorkspace.shared.open(URL(string: "x-apple.systempreferences:com.apple.preference.security?Privacy_Automation")!)
                    }
                }.padding(.top, 8)
            }.font(.caption)
        }
    }
}
