import AppKit
import Combine
#if SWIFT_PACKAGE
import SelaCore
#endif

@MainActor
protocol PowerWarningDelivery {
    func clearPower()
    func schedule(_ plan: TimerPlan)
    func reportPowerFailure(_ detail: String)
}

@MainActor
final class PowerTimerService: ObservableObject {
    struct Draft: Equatable {
        let action: PowerAction
        let seconds: TimeInterval
    }
    @Published private(set) var draft: Draft?
    @Published private(set) var plan: TimerPlan?
    @Published private(set) var remaining: TimeInterval = 0
    @Published private(set) var executing = false
    @Published var message: String?
    @Published private(set) var checkingAccess = false
    @Published private(set) var accessMessage: String?
    private let ticker = DispatchTicker()
    private let notifications: any PowerWarningDelivery
    private let history: UsageHistory
    private var observers: [NSObjectProtocol] = []
    private var sleeping = false
    private let defaults: UserDefaults
    private let now: () -> Date
    private let execute: (PowerAction) async throws -> Void
    var beforeExecution: (() -> Void)?
    init(notifications: any PowerWarningDelivery, history: UsageHistory,
         defaults: UserDefaults = .standard, now: @escaping () -> Date = Date.init,
         execute: @escaping (PowerAction) async throws -> Void = PowerCommand.execute) {
        self.notifications = notifications; self.history = history
        self.defaults = defaults; self.now = now; self.execute = execute
        if defaults.data(forKey: "pendingPowerPlan") != nil {
            message = "Timer dari sesi sebelumnya dibatalkan. Jadwalkan ulang bila diperlukan."
            defaults.removeObject(forKey: "pendingPowerPlan")
        }
        notifications.clearPower()
        let center = NSWorkspace.shared.notificationCenter
        observers.append(center.addObserver(forName: NSWorkspace.willSleepNotification, object: nil, queue: .main) { [weak self] _ in
            MainActor.assumeIsolated { self?.sleeping = true }
        })
        observers.append(center.addObserver(forName: NSWorkspace.didWakeNotification, object: nil, queue: .main) { [weak self] _ in
            MainActor.assumeIsolated {
                guard let self else { return }
                if let plan = self.plan, plan.remaining(at: self.now()) <= 0 {
                    self.cancel()
                    self.message = "Timer terlewat saat Mac tidur dan telah dibatalkan."
                }
                self.sleeping = false
                self.tick()
            }
        })
    }
    func prepare(action: PowerAction, seconds: TimeInterval) {
        guard plan == nil, !executing else { return }
        draft = Draft(action: action, seconds: max(60, min(seconds, 86_400)))
    }
    func discardDraft() { draft = nil }
    func confirmDraft() {
        guard let draft else { return }
        start(action: draft.action, seconds: draft.seconds)
    }
    func start(action: PowerAction, seconds: TimeInterval) {
        guard !executing else { return }
        draft = nil
        let newPlan = TimerPlan(action: action, duration: seconds, now: now())
        plan = newPlan; remaining = newPlan.remaining(at: now()); message = nil
        persist(); notifications.schedule(newPlan)
        history.record("\(action.title) dijadwalkan dalam \(Int(newPlan.duration / 60)) menit")
        ticker.start { [weak self] in self?.tick() }
    }
    func postpone() {
        guard var current = plan, !executing else { return }
        current.postpone(at: now()); plan = current; remaining = current.remaining(at: now())
        persist(); notifications.schedule(current); history.record("Timer daya ditunda 10 menit")
    }
    func cancel() {
        draft = nil
        guard plan != nil else { return }
        ticker.stop(); plan = nil; remaining = 0
        notifications.clearPower(); persist(); history.record("Timer daya dibatalkan")
    }
    func refreshWarnings() {
        if let plan { notifications.schedule(plan) }
    }
    func checkAccess() async {
        guard !checkingAccess else { return }
        checkingAccess = true
        accessMessage = "Jika macOS meminta izin mengontrol System Events, pilih Izinkan."
        defer { checkingAccess = false }
        do {
            _ = try await CommandRunner.run("/usr/bin/osascript", arguments: ["-e", "tell application \"System Events\" to get version"])
            accessMessage = "Akses System Events berhasil. Aksi daya siap diminta ke macOS."
        } catch { accessMessage = PowerCommand.describe(error) }
    }
    private func persist() {
        if let plan { defaults.set(try? JSONEncoder().encode(plan), forKey: "pendingPowerPlan") }
        else { defaults.removeObject(forKey: "pendingPowerPlan") }
    }
    func tick() {
        guard let plan, !sleeping else { return }
        remaining = plan.remaining(at: now())
        guard remaining <= 0, !executing else { return }
        ticker.stop(); self.plan = nil; persist(); notifications.clearPower(); executing = true
        beforeExecution?()
        Task {
            defer { executing = false }
            do {
                try await execute(plan.action)
                message = "Permintaan \(plan.action.title) dikirim ke macOS."
                history.record("Permintaan \(plan.action.title) dikirim")
            } catch {
                message = "Aksi gagal: \(error.localizedDescription)"
                notifications.reportPowerFailure(error.localizedDescription)
                history.record("\(plan.action.title) gagal: \(error.localizedDescription)")
            }
        }
    }
    deinit { for observer in observers { NSWorkspace.shared.notificationCenter.removeObserver(observer) } }
}


enum PowerCommand {
    static func execute(_ action: PowerAction) async throws {
        do { _ = try await CommandRunner.run("/usr/bin/osascript", arguments: ["-e", action.appleScript]) }
        catch { throw CommandFailure(message: describe(error)) }
    }
    static func describe(_ error: Error) -> String {
        let detail = error.localizedDescription
        if detail.contains("-1743") || detail.localizedCaseInsensitiveContains("not authorized") {
            return "Izin Automation ditolak. Buka System Settings → Privacy & Security → Automation, lalu aktifkan System Events untuk Sela."
        }
        if detail.contains("-1712") || detail.contains("(15)") || detail.contains("(9)") {
            return "Permintaan macOS kehabisan waktu. Periksa dialog izin System Events dan coba lagi."
        }
        return detail
    }
}
