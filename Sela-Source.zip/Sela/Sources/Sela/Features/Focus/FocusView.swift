import SwiftUI
#if SWIFT_PACKAGE
import SelaCore
#endif

struct FocusView: View {
    @ObservedObject var service: FocusService
    @ObservedObject var notifications: NotificationService
    @State private var setup = false
    var body: some View {
        FeatureHeader(title: "Focus Timer", subtitle: "Satu hal, satu waktu.")
        VStack(alignment: .leading, spacing: 16) {
            Text(service.phase.rawValue).font(.callout).foregroundStyle(.secondary)
            Text(DisplayFormat.countdown(service.phase == .ready ? Double(service.minutes * 60) : service.remaining))
                .font(.system(size: 48, weight: .light, design: .rounded)).monospacedDigit()
            if service.phase == .ready {
                Picker("Durasi fokus", selection: $service.minutes) {
                    Text("15 menit").tag(15); Text("25 menit").tag(25); Text("45 menit").tag(45); Text("50 menit").tag(50)
                }
            }
            HStack {
                if service.phase == .ready || service.phase == .paused {
                    Button(service.phase == .paused ? "Lanjutkan" : "Mulai fokus", systemImage: "play.fill") {
                        Task { await service.start() }
                    }.buttonStyle(.borderedProminent)
                }
                if service.phase == .focusing { Button("Jeda", systemImage: "pause") { Task { await service.pause() } } }
                if service.phase != .ready { Button("Selesai", role: .cancel) { Task { await service.stop() } } }
            }.disabled(service.busy)
        }
        if service.busy { ProgressView("Menjalankan Shortcuts…").controlSize(.small) }
        Toggle("Do Not Disturb otomatis", isOn: $service.dndEnabled).toggleStyle(.switch).controlSize(.small)
            .disabled(service.phase != .ready || service.busy || service.needsRestore)
        if service.needsRestore && service.phase != .focusing {
            Button("Pulihkan Focus") { Task { await service.restoreDND() } }.disabled(service.busy)
        }
        DisclosureGroup("Pengaturan Shortcuts", isExpanded: $setup) {
            VStack(alignment: .leading, spacing: 12) {
                InfoText("Buat dua shortcut: Focus On menjalankan Set Focus → Do Not Disturb → On; Focus Off menjalankan Set Focus → Do Not Disturb → Off. Gunakan nama persis di bawah.")
                TextField("Shortcut mulai", text: $service.onShortcut)
                TextField("Shortcut selesai", text: $service.offShortcut)
                Button("Buka Shortcuts") { NSWorkspace.shared.open(URL(string: "shortcuts://")!) }
                InfoText("Shortcut Off dijalankan ketika sesi dijeda, selesai, atau Sela ditutup. Pengaturan ini mematikan DND, tidak memulihkan Focus yang sebelumnya aktif. Anda dapat menggantinya dengan shortcut pemulihan sendiri.")
            }.padding(.top, 8).textFieldStyle(.roundedBorder).disabled(service.phase != .ready || service.busy || service.needsRestore)
        }
        if let message = service.message { InfoText(message) }
        InfoText("Jeda 5 menit setelah sesi. Timer ini terpisah dari Power Timer; aksi daya tetap berlaku saat fokus berjalan.")
    }
}
