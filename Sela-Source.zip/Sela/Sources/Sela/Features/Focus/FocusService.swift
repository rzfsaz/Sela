import Foundation
import Combine
#if SWIFT_PACKAGE
import SelaCore
#endif

@MainActor
final class FocusService: ObservableObject {
    enum Phase: String { case ready = "Siap fokus", focusing = "Waktu fokus", paused = "Dijeda", rest = "Waktu istirahat" }
    @Published private(set) var phase: Phase = .ready
    @Published private(set) var remaining: TimeInterval = 25 * 60
    @Published private(set) var busy = false
    @Published var minutes = 25
    @Published var message: String?
    @Published var dndEnabled = UserDefaults.standard.bool(forKey: "focusDND") {
        didSet { UserDefaults.standard.set(dndEnabled, forKey: "focusDND") }
    }
    @Published var onShortcut = UserDefaults.standard.string(forKey: "focusOnShortcut") ?? "Sela · Focus On" {
        didSet { UserDefaults.standard.set(onShortcut, forKey: "focusOnShortcut") }
    }
    @Published var offShortcut = UserDefaults.standard.string(forKey: "focusOffShortcut") ?? "Sela · Focus Off" {
        didSet { UserDefaults.standard.set(offShortcut, forKey: "focusOffShortcut") }
    }
    @Published private(set) var needsRestore = UserDefaults.standard.bool(forKey: "focusOwnsDND")
    private var activeOffShortcut: String?
    private var deadline: Date?
    private let ticker = DispatchTicker()
    private let notifications: NotificationService
    private let history: UsageHistory
    init(notifications: NotificationService, history: UsageHistory) {
        self.notifications = notifications; self.history = history
        activeOffShortcut = UserDefaults.standard.string(forKey: "activeOffShortcut")
    }
    func start() async {
        guard !busy, phase == .ready || phase == .paused else { return }
        busy = true; message = nil
        defer { busy = false }
        if needsRestore { message = "Pulihkan Focus sesi sebelumnya sebelum memulai."; return }
        if dndEnabled {
            do {
                let names = try await CommandRunner.run("/usr/bin/shortcuts", arguments: ["list"])
                let available = Set(names.components(separatedBy: .newlines))
                guard !onShortcut.isEmpty, !offShortcut.isEmpty, available.contains(onShortcut), available.contains(offShortcut) else {
                    message = "Buat kedua shortcut di aplikasi Shortcuts terlebih dahulu."; return
                }
                // Persist recovery before running: if the app exits mid-command, recovery remains visible.
                activeOffShortcut = offShortcut; needsRestore = true
                UserDefaults.standard.set(offShortcut, forKey: "activeOffShortcut")
                UserDefaults.standard.set(true, forKey: "focusOwnsDND")
                _ = try await CommandRunner.run("/usr/bin/shortcuts", arguments: ["run", onShortcut])
            } catch { message = "Focus belum dimulai: \(error.localizedDescription)"; return }
        }
        let duration = phase == .paused ? remaining : Double(minutes * 60)
        remaining = duration; deadline = Date().addingTimeInterval(duration); phase = .focusing
        ticker.start { [weak self] in self?.tick() }
        history.record("Sesi fokus dimulai")
    }
    func pause() async {
        guard phase == .focusing, !busy else { return }
        remaining = max(0, deadline?.timeIntervalSinceNow ?? 0)
        ticker.stop(); deadline = nil; phase = .paused
        await restoreDND()
    }
    func stop() async {
        guard !busy else { return }
        ticker.stop(); deadline = nil; phase = .ready; remaining = Double(minutes * 60)
        await restoreDND()
    }
    func restoreDND() async {
        guard needsRestore, !busy else { return }
        busy = true; defer { busy = false }
        do {
            _ = try await CommandRunner.run("/usr/bin/shortcuts", arguments: ["run", activeOffShortcut ?? offShortcut])
            needsRestore = false; activeOffShortcut = nil
            UserDefaults.standard.set(false, forKey: "focusOwnsDND")
            UserDefaults.standard.removeObject(forKey: "activeOffShortcut")
        } catch { message = "Pemulihan Focus gagal. Coba lagi atau ubah lewat Control Center. \(error.localizedDescription)" }
    }
    private func tick() {
        remaining = max(0, deadline?.timeIntervalSinceNow ?? 0)
        guard remaining <= 0 else { return }
        ticker.stop(); deadline = nil
        if phase == .focusing {
            phase = .rest; remaining = 300
            history.record("Sesi fokus selesai")
            Task {
                await restoreDND()
                notifications.send(id: "focus-complete", title: "Satu sesi selesai", body: "Ambil jeda 5 menit. Anda sudah membuat kemajuan.")
                guard phase == .rest else { return }
                deadline = Date().addingTimeInterval(300)
                ticker.start { [weak self] in self?.tick() }
            }
        } else {
            phase = .ready; remaining = Double(minutes * 60)
            notifications.send(id: "break-complete", title: "Jeda selesai", body: "Mulai sesi baru saat Anda siap.")
        }
    }
}
