import SwiftUI

struct ClipboardView: View {
    @ObservedObject var service: ClipboardService
    var body: some View {
        FeatureHeader(title: "Clipboard", subtitle: "Yang baru disalin, dekat kembali.")
        Toggle("Simpan riwayat sesi", isOn: $service.enabled).toggleStyle(.switch)
        if service.enabled {
            HStack {
                Text("\(service.items.count) dari 15 item").font(.caption).foregroundStyle(.secondary)
                Spacer(); Button("Hapus semua") { service.clear() }.font(.caption).disabled(service.items.isEmpty)
            }
            if service.items.isEmpty { InfoText("Salin teks atau gambar untuk memulai. Riwayat tersimpan di memori, lalu hilang saat aplikasi ditutup.") }
            VStack(spacing: 0) {
                ForEach(service.items) { item in
                    Button { service.use(item) } label: {
                        HStack(spacing: 12) {
                            if let image = item.image { Image(nsImage: image).resizable().scaledToFit().frame(width: 40, height: 40) }
                            else { Image(systemName: "doc.text").frame(width: 24).foregroundStyle(.secondary) }
                            Text(item.title).lineLimit(2).frame(maxWidth: .infinity, alignment: .leading)
                            Image(systemName: "arrow.turn.down.left").font(.caption).foregroundStyle(.tertiary)
                        }.padding(.vertical, 12).contentShape(Rectangle())
                    }.buttonStyle(.plain).help("Gunakan item ini")
                    Divider()
                }
            }
            Picker("Hapus otomatis", selection: $service.expirationMinutes) {
                Text("Saat keluar").tag(0); Text("5 menit").tag(5); Text("30 menit").tag(30); Text("1 jam").tag(60)
            }
            Toggle("Paste otomatis saat diklik", isOn: $service.autoPaste).toggleStyle(.switch).controlSize(.small)
            if service.autoPaste { Button("Izinkan Accessibility") { service.requestAccessibility() }.font(.caption) }
            InfoText("Konten bertanda rahasia dilewati, tetapi tidak semua aplikasi memberi penanda. Matikan riwayat saat menyalin informasi sensitif. Maks. teks 100 KB dan gambar 8 MB per item.")
        }
        if let message = service.message { InfoText(message) }
    }
}
