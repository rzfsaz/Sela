import AppKit
import IOKit.pwr_mgt
import Combine

@MainActor
final class KeepAwakeService: ObservableObject {
    enum Duration: String, CaseIterable, Identifiable {
        case forever = "Selamanya", halfHour = "30 menit", hour = "1 jam", application = "Sampai app ditutup"
        var id: String { rawValue }
    }
    @Published private(set) var active = false
    @Published private(set) var remaining: TimeInterval?
    @Published private(set) var targetName: String?
    @Published var message: String?
    private var assertion: IOPMAssertionID = 0
    private var deadline: Date?
    private var target: NSRunningApplication?
    private let ticker = DispatchTicker()
    func start(duration: Duration, app: NSRunningApplication? = nil) {
        stop()
        if duration == .application && (app == nil || app!.isTerminated) {
            message = "Pilih aplikasi yang sedang berjalan."; return
        }
        let result = IOPMAssertionCreateWithName(kIOPMAssertionTypePreventUserIdleSystemSleep as CFString,
            IOPMAssertionLevel(kIOPMAssertionLevelOn), "Sela Keep Awake" as CFString, &assertion)
        guard result == kIOReturnSuccess else { message = "Keep Awake gagal diaktifkan (\(result))."; return }
        active = true; message = nil
        switch duration {
        case .forever: deadline = nil
        case .halfHour: deadline = Date().addingTimeInterval(1800)
        case .hour: deadline = Date().addingTimeInterval(3600)
        case .application: target = app; targetName = app?.localizedName
        }
        update(); ticker.start { [weak self] in self?.update() }
    }
    func stop() {
        if active { IOPMAssertionRelease(assertion) }
        assertion = 0; active = false; deadline = nil; remaining = nil; target = nil; targetName = nil
        ticker.stop()
    }
    private func update() {
        if target?.isTerminated == true { stop(); return }
        if let deadline {
            remaining = max(0, deadline.timeIntervalSinceNow)
            if remaining == 0 { stop() }
        }
    }
    deinit { if assertion != 0 { IOPMAssertionRelease(assertion) } }
}
