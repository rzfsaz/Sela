import SwiftUI
#if SWIFT_PACKAGE
import SelaCore
#endif

struct KeepAwakeView: View {
    @ObservedObject var service: KeepAwakeService
    @State private var duration: KeepAwakeService.Duration = .forever
    @State private var applications: [NSRunningApplication] = []
    @State private var selectedPID: pid_t = 0
    var body: some View {
        FeatureHeader(title: "Keep Awake", subtitle: "Tetap terjaga. Selama Anda perlu.")
        Surface {
            HStack(spacing: 16) {
                Image(systemName: service.active ? "cup.and.saucer.fill" : "cup.and.saucer")
                    .font(.system(size: 32, weight: .light)).foregroundStyle(service.active ? Color.accentColor : .secondary)
                VStack(alignment: .leading, spacing: 4) {
                    Text(service.active ? "Mac tetap terjaga" : "Istirahat seperti biasa").font(.headline)
                    Text(service.active ? "Layar boleh redup" : "Mengikuti pengaturan sistem").font(.caption).foregroundStyle(.secondary)
                }
                Spacer(minLength: 0)
                Toggle("Keep Awake", isOn: Binding(get: { service.active }, set: { enabled in
                    if enabled { service.start(duration: duration, app: applications.first { $0.processIdentifier == selectedPID }) }
                    else { service.stop() }
                })).labelsHidden().toggleStyle(.switch)
            }
        }
        Picker("Durasi", selection: $duration) { ForEach(KeepAwakeService.Duration.allCases) { Text($0.rawValue).tag($0) } }
            .disabled(service.active)
        if duration == .application {
            Picker("Aplikasi", selection: $selectedPID) {
                Text("Pilih aplikasi").tag(pid_t(0))
                ForEach(applications, id: \.processIdentifier) { Text($0.localizedName ?? "Aplikasi").tag($0.processIdentifier) }
            }.disabled(service.active)
            Button("Perbarui daftar") { refreshApps() }.font(.caption).disabled(service.active)
        }
        if let remaining = service.remaining { Label(DisplayFormat.countdown(remaining), systemImage: "clock").monospacedDigit() }
        if let target = service.targetName { InfoText("Aktif sampai \(target) ditutup.") }
        if let message = service.message { InfoText(message) }
        InfoText("Mencegah sleep otomatis karena tidak ada aktivitas. Menutup layar laptop, memilih Sleep, atau baterai kritis tetap dapat membuat Mac tidur. Timer daya tetap berlaku.")
        Color.clear.frame(height: 0).onAppear(perform: refreshApps)
    }
    private func refreshApps() {
        applications = NSWorkspace.shared.runningApplications.filter {
            $0.activationPolicy == .regular && $0.processIdentifier != ProcessInfo.processInfo.processIdentifier
        }.sorted { ($0.localizedName ?? "") < ($1.localizedName ?? "") }
        if !applications.contains(where: { $0.processIdentifier == selectedPID }) { selectedPID = 0 }
    }
}
