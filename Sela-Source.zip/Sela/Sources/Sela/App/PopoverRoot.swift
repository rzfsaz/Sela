import SwiftUI

private enum Section: String, CaseIterable, Identifiable {
    case power = "Power Timer", awake = "Keep Awake", battery = "Battery Health", clipboard = "Clipboard"
    case cleaner = "Quick Cleaner", network = "Network", notes = "Quick Notes", focus = "Focus Timer"
    var id: String { rawValue }
    var symbol: String {
        switch self { case .power: return "timer"; case .awake: return "cup.and.saucer"
        case .battery: return "battery.100percent"; case .clipboard: return "clipboard"
        case .cleaner: return "sparkles"; case .network: return "network"
        case .notes: return "note.text"; case .focus: return "scope" }
    }
}
struct PopoverRoot: View {
    @ObservedObject var model: AppModel
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var section: Section = .power
    @State private var preferences = false
    @State private var greeting = true
    @State private var session = UUID()
    @State private var visible = false
    @State private var quitConfirmation = false
    init(model: AppModel, showGreeting: Bool = true, initialSection: String = "Power Timer") {
        self.model = model
        _greeting = State(initialValue: showGreeting)
        _section = State(initialValue: Section(rawValue: initialSection) ?? .power)
    }
    var body: some View {
        ZStack {
            // Keep feature state alive while the greeting overlays the interface.
            mainContent.opacity(greeting ? 0 : 1)
                .allowsHitTesting(!greeting).accessibilityHidden(greeting)
            if greeting { GreetingView(skip: dismissGreeting).transition(.opacity) }
        }
        .frame(width: 600, height: 504)
        .buttonBorderShape(.roundedRectangle(radius: 6))
        .onExitCommand { model.popoverWindow?.orderOut(nil) }
        .background(.ultraThinMaterial)
        .background(PopoverLifecycle { isVisible, window in
            visible = isVisible
            if isVisible {
                if let previous = model.popoverWindow, previous !== window { previous.orderOut(nil) }
                model.popoverWindow = window
                greeting = true; session = UUID(); model.rememberFrontmostApplication()
            } else { session = UUID() }
        })
        .task(id: session) {
            guard visible, greeting else { return }
            do { try await Task.sleep(for: .milliseconds(1500)) } catch { return }
            dismissGreeting()
        }
        .alert("Keluar dari Sela?", isPresented: $quitConfirmation) {
            Button("Batal", role: .cancel) {}
            Button("Keluar", role: .destructive) { NSApp.terminate(nil) }
        } message: { Text("Timer dibatalkan, Keep Awake berhenti, dan riwayat clipboard sesi ini dihapus.") }
    }
    private func dismissGreeting() { withAnimation(.spring(response: reduceMotion ? 0.15 : 0.38, dampingFraction: 0.9)) { greeting = false } }
    private var mainContent: some View {
        HStack(spacing: 0) {
            VStack(alignment: .leading, spacing: 16) {
                HStack(spacing: 8) {
                    Image(systemName: "circle.lefthalf.filled").font(.system(size: 19))
                    Text("Sela").font(.system(size: 18, weight: .semibold))
                }.padding(.horizontal, 8).padding(.top, 8)
                VStack(spacing: 4) {
                    ForEach(Section.allCases) { item in
                        if item == .battery { Divider().padding(.vertical, 8) }
                        Button {
                            preferences = false
                            withAnimation(.spring(response: 0.3, dampingFraction: 0.9)) { section = item }
                        } label: {
                            Label(item.rawValue, systemImage: item.symbol)
                                .font(.system(size: 12, weight: section == item && !preferences ? .semibold : .regular))
                                .frame(maxWidth: .infinity, alignment: .leading).padding(.horizontal, 8).padding(.vertical, 9)
                                .contentShape(Rectangle())
                                .background(section == item && !preferences ? Color.accentColor.opacity(0.14) : .clear,
                                    in: RoundedRectangle(cornerRadius: 6))
                        }.buttonStyle(.plain).accessibilityAddTraits(section == item && !preferences ? .isSelected : [])
                    }
                }
                Spacer(minLength: 0)
                HStack {
                    Button { preferences.toggle() } label: { Image(systemName: "gearshape") }.help("Pengaturan")
                    Spacer()
                    Button { model.popoverWindow?.orderOut(nil) } label: { Image(systemName: "xmark") }
                        .accessibilityLabel("Tutup panel").help("Tutup panel (Esc). Sela tetap di menu bar.")
                    Spacer()
                    Button { quitConfirmation = true } label: { Image(systemName: "power") }.accessibilityLabel("Keluar dari Sela").help("Keluar dari Sela")
                }.buttonStyle(.borderless).foregroundStyle(.secondary).padding(.horizontal, 8)
            }.padding(16).frame(width: 176)
            Divider()
            ScrollView {
                VStack(alignment: .leading, spacing: 24) {
                    if preferences { PreferencesView(notifications: model.notifications, history: model.history) }
                    else { content }
                }.padding(24).frame(maxWidth: .infinity, alignment: .topLeading)
            }.background(.background.opacity(0.45))
        }
    }
    @ViewBuilder private var content: some View {
        switch section {
        case .power: PowerTimerView(service: model.power, notifications: model.notifications)
        case .awake: KeepAwakeView(service: model.awake)
        case .battery: BatteryView(service: model.battery, notifications: model.notifications)
        case .clipboard: ClipboardView(service: model.clipboard)
        case .cleaner: CleanerView(service: model.cleaner)
        case .network: NetworkView(service: model.network)
        case .notes: NotesView(service: model.notes)
        case .focus: FocusView(service: model.focus, notifications: model.notifications)
        }
    }
}

private struct PreferencesView: View {
    @ObservedObject var notifications: NotificationService
    @ObservedObject var history: UsageHistory
    var body: some View {
        FeatureHeader(title: "Pengaturan", subtitle: "Ruang kecil yang bekerja untuk Anda.")
        Surface {
            Text(notifications.status).font(.callout)
            Button("Izinkan notifikasi") { Task { await notifications.request() } }
            InfoText("Peringatan mengikuti pengaturan notifikasi dan Focus macOS.")
        }
        VStack(alignment: .leading, spacing: 12) {
            HStack { Text("Aktivitas terakhir").font(.headline); Spacer(); Button("Hapus") { history.clear() }.font(.caption) }
            if history.entries.isEmpty { InfoText("Belum ada aktivitas.") }
            ForEach(history.entries.prefix(8)) { entry in
                VStack(alignment: .leading, spacing: 4) {
                    Text(entry.text).font(.caption)
                    Text(entry.date, format: .dateTime.day().month().hour().minute()).font(.caption2).foregroundStyle(.secondary)
                }
            }
        }
        InfoText("Sela 1.0 · macOS 14+ · Apple Silicon\nCatatan dan preferensi tersimpan lokal. Riwayat clipboard tidak ditulis ke disk.")
    }
}
