import SwiftUI
#if SWIFT_PACKAGE
import SelaCore
#endif

@main
struct SelaApp: App {
    @NSApplicationDelegateAdaptor(AppDelegate.self) private var delegate
    @StateObject private var model = AppModel.shared
    init() {
        if !ProcessInfo.processInfo.arguments.contains("--render-previews"), !SingleInstance.acquire() { exit(0) }
        #if DEBUG
        let arguments = ProcessInfo.processInfo.arguments
        if let index = arguments.firstIndex(of: "--render-previews"), arguments.indices.contains(index + 1) {
            let directory = URL(fileURLWithPath: arguments[index + 1], isDirectory: true)
            Task { @MainActor in
                do { try PreviewExport.write(to: directory); exit(0) }
                catch { print(error.localizedDescription); exit(1) }
            }
        }
        #endif
    }
    var body: some Scene {
        MenuBarExtra {
            // Use one persistent panel for both menu-bar clicks and Finder reopen.
            // SwiftUI's transient MenuBarExtra host must never own timer confirmation state.
            Color.clear.frame(width: 1, height: 1)
                .background(PopoverLifecycle { visible, window in
                    guard visible, let window, window.isVisible else { return }
                    delegate.openFromMenuBar(host: window)
                })
        } label: {
            StatusLabel(power: model.power, awake: model.awake, network: model.network)
        }
        .menuBarExtraStyle(.window)
    }
}

struct StatusLabel: View {
    @ObservedObject var power: PowerTimerService
    @ObservedObject var awake: KeepAwakeService
    @ObservedObject var network: NetworkService
    var body: some View {
        HStack(spacing: 4) {
            Image(systemName: power.plan?.action.symbol ?? (awake.active ? "cup.and.saucer.fill" : "circle.lefthalf.filled"))
            if power.plan != nil { Text(DisplayFormat.countdown(power.remaining)).monospacedDigit() }
            else { Text("Sela") }
            if network.showInMenuBar {
                Text("↓\(DisplayFormat.rate(network.download)) ↑\(DisplayFormat.rate(network.upload))")
                    .font(.system(size: 10, weight: .medium, design: .monospaced))
            }
        }
        .accessibilityLabel("Sela" + (power.plan == nil ? "" : ", timer \(DisplayFormat.countdown(power.remaining))"))
        .help("Sela · utilitas Mac Anda")
    }
}
