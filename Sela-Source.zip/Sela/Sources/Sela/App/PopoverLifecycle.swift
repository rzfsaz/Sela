import AppKit
import SwiftUI

// MenuBarExtra can retain its SwiftUI content between presentations.
// Observe its actual NSWindow instead of relying solely on onAppear.
struct PopoverLifecycle: NSViewRepresentable {
    var onVisibility: (Bool, NSWindow?) -> Void
    func makeNSView(context: Context) -> Probe {
        let view = Probe(); view.onVisibility = onVisibility; return view
    }
    func updateNSView(_ view: Probe, context: Context) { view.onVisibility = onVisibility }
    final class Probe: NSView {
        var onVisibility: ((Bool, NSWindow?) -> Void)?
        private var observation: NSKeyValueObservation?
        private var keyObserver: NSObjectProtocol?
        private var occlusionObserver: NSObjectProtocol?
        private var lastVisible = false
        override func viewDidMoveToWindow() {
            super.viewDidMoveToWindow()
            observation = nil
            if let keyObserver { NotificationCenter.default.removeObserver(keyObserver) }
            if let occlusionObserver { NotificationCenter.default.removeObserver(occlusionObserver) }
            guard let window else { report(false); return }
            observation = window.observe(\.isVisible, options: [.initial, .new]) { [weak self] window, _ in
                DispatchQueue.main.async { self?.report(window.isVisible) }
            }
            keyObserver = NotificationCenter.default.addObserver(forName: NSWindow.didBecomeKeyNotification,
                object: window, queue: .main) { [weak self, weak window] _ in self?.report(window?.isVisible ?? false) }
            occlusionObserver = NotificationCenter.default.addObserver(forName: NSWindow.didChangeOcclusionStateNotification,
                object: window, queue: .main) { [weak self, weak window] _ in
                    self?.report(window?.isVisible ?? false)
                }
        }
        private func report(_ visible: Bool) {
            guard visible != lastVisible else { return }
            lastVisible = visible; onVisibility?(visible, window)
        }
        deinit {
            if let keyObserver { NotificationCenter.default.removeObserver(keyObserver) }
            if let occlusionObserver { NotificationCenter.default.removeObserver(occlusionObserver) }
        }
    }
}
