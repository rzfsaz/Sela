import SwiftUI
import AppKit

@MainActor
final class AppModel: ObservableObject {
    static let shared = AppModel()
    let notifications = NotificationService()
    let history = UsageHistory()
    let awake = KeepAwakeService()
    let clipboard = ClipboardService()
    let network = NetworkService()
    let notes = NotesService()
    let cleaner = CleanerService()
    let power: PowerTimerService
    let battery: BatteryService
    let focus: FocusService
    weak var popoverWindow: NSWindow?
    private var activationObserver: NSObjectProtocol?
    init() {
        power = PowerTimerService(notifications: notifications, history: history)
        battery = BatteryService(notifications: notifications)
        focus = FocusService(notifications: notifications, history: history)
        power.beforeExecution = { [weak self] in self?.awake.stop() }
        notifications.powerCancel = { [weak power] in power?.cancel() }
        notifications.powerPostpone = { [weak power] in power?.postpone() }
        clipboard.closePopover = { [weak self] in self?.popoverWindow?.orderOut(nil) }
        rememberFrontmostApplication()
        activationObserver = NSWorkspace.shared.notificationCenter.addObserver(
            forName: NSWorkspace.didActivateApplicationNotification, object: nil, queue: .main) { [weak self] _ in
                MainActor.assumeIsolated { self?.rememberFrontmostApplication() }
            }
    }
    func rememberFrontmostApplication() {
        if let app = NSWorkspace.shared.frontmostApplication,
           app.processIdentifier != ProcessInfo.processInfo.processIdentifier {
            clipboard.destination = app
        }
    }
    deinit { if let activationObserver { NSWorkspace.shared.notificationCenter.removeObserver(activationObserver) } }
}

@MainActor
final class AppDelegate: NSObject, NSApplicationDelegate {
    weak var model: AppModel?
    private var terminating = false
    private let launchPanel = LaunchPanelController()
    func applicationDidFinishLaunching(_ notification: Notification) {
        NSApp.setActivationPolicy(.accessory)
        model = AppModel.shared
        DistributedNotificationCenter.default().addObserver(self, selector: #selector(showPanel),
            name: SingleInstance.showNotification, object: nil)
        if !ProcessInfo.processInfo.arguments.contains("--render-previews") { showPanel() }
    }
    @objc private func showPanel() {
        guard let model else { return }
        launchPanel.show(model: model)
    }
    func openFromMenuBar(host: NSWindow) {
        let wasVisible = launchPanel.isVisible
        host.orderOut(nil)
        if wasVisible { launchPanel.hide() }
        else { launchPanel.show(model: model ?? AppModel.shared) }
    }
    func applicationShouldHandleReopen(_ sender: NSApplication, hasVisibleWindows flag: Bool) -> Bool {
        showPanel()
        return false
    }
    func applicationShouldTerminate(_ sender: NSApplication) -> NSApplication.TerminateReply {
        guard let model, !terminating else { return .terminateNow }
        if model.focus.busy || model.power.executing { return .terminateCancel }
        terminating = true
        model.awake.stop(); model.power.cancel()
        Task {
            await model.focus.stop()
            if model.focus.needsRestore {
                let alert = NSAlert()
                alert.messageText = "Do Not Disturb belum dipulihkan"
                alert.informativeText = "Pulihkan melalui Control Center, atau kembali ke Sela untuk mencoba lagi."
                alert.addButton(withTitle: "Kembali ke Sela")
                alert.addButton(withTitle: "Keluar")
                if alert.runModal() == .alertFirstButtonReturn {
                    terminating = false; sender.reply(toApplicationShouldTerminate: false); return
                }
            }
            sender.reply(toApplicationShouldTerminate: true)
        }
        return .terminateLater
    }
}
