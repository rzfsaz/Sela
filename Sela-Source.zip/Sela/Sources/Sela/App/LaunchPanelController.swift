import AppKit
import SwiftUI
import Darwin

// MenuBarExtra remains the primary scene. Finder launches/reopens also reveal this
// borderless transient panel, so a hidden menu bar icon never prevents access.
@MainActor
final class LaunchPanelController {
    private var panel: SelaPanel?
    var isVisible: Bool { panel?.isVisible == true }
    func show(model: AppModel) {
        model.rememberFrontmostApplication()
        // A panel hidden when its app deactivates may still report isVisible.
        // Always activate and raise it on reopen rather than returning early.
        if let previous = model.popoverWindow, previous !== self.panel { previous.orderOut(nil) }
        let panel: SelaPanel
        if let existing = self.panel { panel = existing }
        else {
            panel = SelaPanel(contentRect: NSRect(x: 0, y: 0, width: 600, height: 504),
                              styleMask: [.borderless], backing: .buffered, defer: false)
            panel.title = "Sela"
            panel.identifier = NSUserInterfaceItemIdentifier("SelaLaunchPanel")
            panel.isReleasedWhenClosed = false
            panel.isOpaque = false
            panel.backgroundColor = .clear
            panel.hasShadow = true
            panel.level = .popUpMenu
            panel.hidesOnDeactivate = false
            panel.collectionBehavior = [.moveToActiveSpace, .fullScreenAuxiliary]
            panel.contentView = NSHostingView(rootView: PopoverRoot(model: model)
                .clipShape(RoundedRectangle(cornerRadius: 10)))
            self.panel = panel
        }
        let screen = NSScreen.screens.first(where: { $0.frame.contains(NSEvent.mouseLocation) }) ?? NSScreen.main
        if let frame = screen?.visibleFrame {
            panel.setFrameOrigin(NSPoint(x: frame.maxX - 612, y: frame.maxY - 512))
        }
        model.popoverWindow = panel
        NSApp.unhide(nil)
        NSApp.activate(ignoringOtherApps: true)
        panel.makeKeyAndOrderFront(nil)
        panel.orderFrontRegardless()
        NSLog("Sela launch panel: visible=%d key=%d", panel.isVisible ? 1 : 0, panel.isKeyWindow ? 1 : 0)
    }
    func hide() { panel?.orderOut(nil) }
}

private final class SelaPanel: NSPanel {
    override var canBecomeKey: Bool { true }
    override var canBecomeMain: Bool { false }
    override func cancelOperation(_ sender: Any?) { orderOut(sender) }
}

@MainActor
enum SingleInstance {
    static let showNotification = Notification.Name("com.sela.utility.showPanel")
    private static var lockDescriptor: Int32 = -1
    static func acquire() -> Bool {
        if lockDescriptor >= 0 { return true }
        let directory = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("com.sela.utility", isDirectory: true)
        do { try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true) }
        catch { return true }
        let descriptor = open(directory.appendingPathComponent("instance.lock").path, O_CREAT | O_RDWR | O_CLOEXEC, 0o600)
        guard descriptor >= 0 else { return true }
        if flock(descriptor, LOCK_EX | LOCK_NB) == 0 { lockDescriptor = descriptor; return true }
        close(descriptor)
        DistributedNotificationCenter.default().postNotificationName(showNotification, object: nil, userInfo: nil, deliverImmediately: true)
        return false
    }
}
