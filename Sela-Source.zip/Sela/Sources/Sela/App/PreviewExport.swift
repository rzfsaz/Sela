#if DEBUG
import SwiftUI
import AppKit

// Render only our own offscreen view hierarchy; no screen capture or Accessibility access.
@MainActor
enum PreviewExport {
    static func write(to directory: URL) throws {
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        let model = AppModel()
        for dark in [false, true] {
            for section in ["Greeting", "Power Timer", "Keep Awake", "Battery Health", "Clipboard", "Quick Cleaner", "Network", "Quick Notes", "Focus Timer"] {
                let view = PopoverRoot(model: model, showGreeting: section == "Greeting", initialSection: section)
                    .environment(\.colorScheme, dark ? .dark : .light)
                let hosting = NSHostingView(rootView: view)
                hosting.appearance = NSAppearance(named: dark ? .darkAqua : .aqua)
                hosting.frame = NSRect(x: 0, y: 0, width: 600, height: 504)
                hosting.layoutSubtreeIfNeeded()
                guard let bitmap = hosting.bitmapImageRepForCachingDisplay(in: hosting.bounds) else { continue }
                hosting.cacheDisplay(in: hosting.bounds, to: bitmap)
                guard let data = bitmap.representation(using: .png, properties: [:]) else { continue }
                let name = "\(section.replacingOccurrences(of: " ", with: ""))-\(dark ? "Dark" : "Light").png"
                try data.write(to: directory.appendingPathComponent(name))
            }
        }
    }
}
#endif
