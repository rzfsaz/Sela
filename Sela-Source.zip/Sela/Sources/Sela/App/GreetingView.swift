import SwiftUI
#if SWIFT_PACKAGE
import SelaCore
#endif

struct GreetingView: View {
    var skip: () -> Void
    private var name: String {
        let fullName = NSFullUserName().trimmingCharacters(in: .whitespacesAndNewlines)
        return fullName.isEmpty ? NSUserName() : fullName
    }
    var body: some View {
        Button(action: skip) {
            VStack(spacing: 16) {
                Image(systemName: (5..<18).contains(Calendar.current.component(.hour, from: Date())) ? "sun.max" : "moon")
                    .font(.system(size: 28, weight: .light)).foregroundStyle(.secondary)
                VStack(spacing: 8) {
                    Text(DisplayFormat.greeting(hour: Calendar.current.component(.hour, from: Date())))
                        .font(.system(size: 15)).foregroundStyle(.secondary)
                    Text(name).font(.system(size: 27, weight: .medium)).lineLimit(2)
                    Text("Sedikit ruang untuk hari Anda.").foregroundStyle(.secondary).padding(.top, 4)
                }
                Text("Klik untuk melanjutkan").font(.caption).foregroundStyle(.tertiary).padding(.top, 16)
            }
            .padding(32).frame(maxWidth: .infinity, maxHeight: .infinity).contentShape(Rectangle())
        }
        .buttonStyle(.plain).accessibilityLabel("\(DisplayFormat.greeting(hour: Calendar.current.component(.hour, from: Date()))), \(name). Lanjutkan")
    }
}
