import Foundation

public enum PowerAction: String, CaseIterable, Codable, Identifiable, Sendable {
    case sleep, shutdown, restart, logout
    public var id: String { rawValue }
    public var title: String {
        switch self { case .sleep: return "Sleep"; case .shutdown: return "Shutdown"
        case .restart: return "Restart"; case .logout: return "Log Out" }
    }
    public var symbol: String {
        switch self { case .sleep: return "moon.zzz"; case .shutdown: return "power"
        case .restart: return "arrow.clockwise"; case .logout: return "rectangle.portrait.and.arrow.right" }
    }
    public var appleScript: String {
        switch self { case .sleep: return "tell application \"System Events\" to sleep"
        case .shutdown: return "tell application \"System Events\" to shut down"
        case .restart: return "tell application \"System Events\" to restart"
        case .logout: return "tell application \"System Events\" to log out" }
    }
}

public struct TimerPlan: Codable, Equatable, Sendable {
    public var action: PowerAction
    public var deadline: Date
    public var duration: TimeInterval
    public init(action: PowerAction, duration: TimeInterval, now: Date = Date()) {
        self.action = action
        self.duration = max(60, min(duration, 86_400))
        self.deadline = now.addingTimeInterval(self.duration)
    }
    public func remaining(at now: Date = Date()) -> TimeInterval { max(0, deadline.timeIntervalSince(now)) }
    public mutating func postpone(at now: Date = Date()) {
        deadline = max(deadline, now).addingTimeInterval(600)
        duration += 600
    }
    public func warningDelays(at now: Date = Date()) -> [(minutes: Int, delay: TimeInterval)] {
        [5, 1].compactMap { minutes in
            let delay = remaining(at: now) - Double(minutes * 60)
            return delay > 0 ? (minutes, delay) : nil
        }
    }
}

public enum DisplayFormat {
    public static func countdown(_ seconds: TimeInterval) -> String {
        let value = max(0, Int(ceil(seconds)))
        if value >= 3600 { return String(format: "%d:%02d:%02d", value / 3600, (value % 3600) / 60, value % 60) }
        return String(format: "%02d:%02d", value / 60, value % 60)
    }
    public static func bytes(_ value: Int64) -> String {
        ByteCountFormatter.string(fromByteCount: value, countStyle: .file)
    }
    public static func rate(_ value: Double) -> String {
        let amount = max(0, value)
        if amount >= 1_000_000 { return String(format: "%.1f MB/s", amount / 1_000_000) }
        return String(format: "%.0f KB/s", amount / 1_000)
    }
    public static func greeting(hour: Int) -> String {
        switch hour { case 5..<11: return "Selamat pagi"; case 11..<15: return "Selamat siang"
        case 15..<18: return "Selamat sore"; default: return "Selamat malam" }
    }
}

public struct NetworkCounters: Equatable, Sendable {
    public var received: UInt64
    public var sent: UInt64
    public init(received: UInt64, sent: UInt64) { self.received = received; self.sent = sent }
    public func rates(since previous: Self, elapsed: Double) -> (download: Double, upload: Double) {
        guard elapsed > 0, received >= previous.received, sent >= previous.sent else { return (0, 0) }
        return (Double(received - previous.received) / elapsed, Double(sent - previous.sent) / elapsed)
    }
}
