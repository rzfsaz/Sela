import Foundation
import Darwin

public enum CleanCategory: String, CaseIterable, Identifiable, Sendable {
    case caches, logs, trash
    public var id: String { rawValue }
    public var title: String { switch self { case .caches: return "Cache"; case .logs: return "Log"; case .trash: return "Trash" } }
}
public struct CleanCandidate: Identifiable, Sendable {
    public var id: String { url.path }
    public let url: URL
    public let root: URL
    public let category: CleanCategory
    public let bytes: Int64
    public let inode: UInt64
    public let device: Int32
    public let size: Int64
    public let modifiedSeconds: Int
    public let modifiedNanos: Int
    public let changedSeconds: Int
    public let changedNanos: Int
}
public struct CleanPreview: Sendable {
    public var files: [CleanCandidate] = []
    public var warnings: [String] = []
    public init() {}
}
public struct CleanResult: Sendable {
    public var freed: Int64 = 0
    public var deleted = 0
    public var skipped = 0
    public init() {}
}

public enum SafeCleaner {
    // Only regular files are eligible. Never follow aliases, symlinks or directory symlinks.
    public static func scan(roots: [(CleanCategory, URL)], now: Date = Date(), limit: Int = 20_000) -> CleanPreview {
        var preview = CleanPreview()
        let fm = FileManager.default
        for (category, root) in roots {
            var metadata = stat()
            guard lstat(root.path, &metadata) == 0, metadata.st_mode & S_IFMT == S_IFDIR else {
                preview.warnings.append("\(category.title): folder tidak tersedia atau tidak dapat diakses.")
                continue
            }
            // Foundation standardization can rewrite /private/var to /var (a symlink).
            // Keep the POSIX canonical path for descriptor-based traversal.
            guard let resolved = realpath(root.path, nil) else { continue }
            let root = URL(fileURLWithPath: String(cString: resolved), isDirectory: true)
            free(resolved)
            var enumerationFailed = false
            guard let walker = fm.enumerator(at: root, includingPropertiesForKeys: nil, options: [], errorHandler: { _, _ in
                enumerationFailed = true; return true
            }) else { continue }
            for case let url as URL in walker {
                if preview.files.count >= limit {
                    preview.warnings.append("Preview dibatasi \(limit) file; pindai lagi setelah selesai.")
                    return preview
                }
                if url.pathComponents.contains("com.sela.utility") { walker.skipDescendants(); continue }
                var info = stat()
                guard lstat(url.path, &info) == 0 else { continue }
                if info.st_mode & S_IFMT == S_IFLNK { walker.skipDescendants(); continue }
                guard info.st_mode & S_IFMT == S_IFREG, info.st_nlink == 1 else { continue }
                let modified = Date(timeIntervalSince1970: Double(info.st_mtimespec.tv_sec))
                guard category == .trash || now.timeIntervalSince(modified) >= 7 * 86_400 else { continue }
                preview.files.append(CleanCandidate(url: url, root: root, category: category,
                    bytes: Int64(info.st_blocks) * 512, inode: UInt64(info.st_ino), device: info.st_dev,
                    size: info.st_size, modifiedSeconds: info.st_mtimespec.tv_sec, modifiedNanos: info.st_mtimespec.tv_nsec,
                    changedSeconds: info.st_ctimespec.tv_sec, changedNanos: info.st_ctimespec.tv_nsec))
            }
            if enumerationFailed { preview.warnings.append("\(category.title): sebagian folder ditolak macOS dan dilewati.") }
        }
        return preview
    }

    public static func delete(_ candidates: [CleanCandidate]) -> CleanResult {
        var result = CleanResult()
        for candidate in candidates {
            if deleteUnchanged(candidate) { result.deleted += 1; result.freed += candidate.bytes }
            else { result.skipped += 1 }
        }
        return result
    }

    private static func deleteUnchanged(_ candidate: CleanCandidate) -> Bool {
        let root = candidate.root.pathComponents
        let path = candidate.url.pathComponents
        guard path.count > root.count, Array(path.prefix(root.count)) == root,
              !path.contains(".."), let filename = path.last else { return false }
        // Anchor each path component to an open descriptor to resist symlink substitution.
        var descriptor = open("/", O_RDONLY | O_DIRECTORY | O_NOFOLLOW)
        guard descriptor >= 0 else { return false }
        for component in path.dropFirst().dropLast() {
            let next = openat(descriptor, component, O_RDONLY | O_DIRECTORY | O_NOFOLLOW)
            close(descriptor)
            guard next >= 0 else { return false }
            descriptor = next
        }
        defer { close(descriptor) }
        var info = stat()
        guard fstatat(descriptor, filename, &info, AT_SYMLINK_NOFOLLOW) == 0,
              info.st_mode & S_IFMT == S_IFREG, info.st_nlink == 1,
              UInt64(info.st_ino) == candidate.inode, info.st_dev == candidate.device,
              info.st_size == candidate.size,
              info.st_mtimespec.tv_sec == candidate.modifiedSeconds,
              info.st_mtimespec.tv_nsec == candidate.modifiedNanos,
              info.st_ctimespec.tv_sec == candidate.changedSeconds,
              info.st_ctimespec.tv_nsec == candidate.changedNanos else { return false }
        return unlinkat(descriptor, filename, 0) == 0
    }
}
