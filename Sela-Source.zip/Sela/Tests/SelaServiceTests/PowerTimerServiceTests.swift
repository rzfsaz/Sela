import XCTest
import SelaCore
@testable import Sela

@MainActor
private final class WarningSpy: PowerWarningDelivery {
    var scheduled: [TimerPlan] = []
    var clearCount = 0
    var failures: [String] = []
    func clearPower() { clearCount += 1 }
    func schedule(_ plan: TimerPlan) { scheduled.append(plan) }
    func reportPowerFailure(_ detail: String) { failures.append(detail) }
}

final class PowerTimerServiceTests: XCTestCase {
    @MainActor
    func testConfirmationDraftIsIndependentOfPopoverLifetime() {
        let defaults = UserDefaults(suiteName: "SelaTests-" + UUID().uuidString)!
        let service = PowerTimerService(notifications: WarningSpy(), history: UsageHistory(defaults: defaults), defaults: defaults)
        service.prepare(action: .shutdown, seconds: 1800)
        XCTAssertNil(service.plan)
        XCTAssertEqual(service.draft?.action, .shutdown)
        // Views may be dismissed or recreated; confirmation data belongs to the retained service.
        service.confirmDraft()
        XCTAssertNil(service.draft)
        XCTAssertEqual(service.plan?.action, .shutdown)
        XCTAssertGreaterThan(service.remaining, 1798)
        service.cancel()
    }
    @MainActor
    func testReturningFromConfirmationDoesNotScheduleAnyAction() {
        let defaults = UserDefaults(suiteName: "SelaTests-" + UUID().uuidString)!
        let warnings = WarningSpy()
        let service = PowerTimerService(notifications: warnings, history: UsageHistory(defaults: defaults), defaults: defaults)
        service.prepare(action: .sleep, seconds: 900)
        service.discardDraft()
        service.confirmDraft()
        XCTAssertNil(service.plan)
        XCTAssertNil(service.draft)
        XCTAssertTrue(warnings.scheduled.isEmpty)
    }
    @MainActor
    func testScheduleStartsSynchronouslyWithoutNotificationPermission() {
        let defaults = UserDefaults(suiteName: "SelaTests-" + UUID().uuidString)!
        let warnings = WarningSpy()
        let service = PowerTimerService(notifications: warnings, history: UsageHistory(defaults: defaults), defaults: defaults)
        service.start(action: .sleep, seconds: 1800)
        XCTAssertEqual(service.plan?.action, .sleep)
        XCTAssertGreaterThan(service.remaining, 1798)
        XCTAssertEqual(warnings.scheduled.count, 1)
        service.cancel()
    }
    @MainActor
    func testDeadlineExecutesSelectedActionOnlyOnce() async {
        let defaults = UserDefaults(suiteName: "SelaTests-" + UUID().uuidString)!
        let warnings = WarningSpy()
        var clock = Date(timeIntervalSince1970: 1000)
        var actions: [PowerAction] = []
        let service = PowerTimerService(notifications: warnings, history: UsageHistory(defaults: defaults),
            defaults: defaults, now: { clock }, execute: { actions.append($0) })
        service.start(action: .shutdown, seconds: 60)
        clock = clock.addingTimeInterval(61)
        service.tick(); service.tick()
        for _ in 0..<10 { await Task.yield() }
        XCTAssertEqual(actions, [.shutdown])
        XCTAssertNil(service.plan)
        XCTAssertFalse(service.executing)
    }
    @MainActor
    func testCancelPreventsExecutionAfterDeadline() async {
        let defaults = UserDefaults(suiteName: "SelaTests-" + UUID().uuidString)!
        let warnings = WarningSpy()
        var clock = Date(timeIntervalSince1970: 1000)
        var executions = 0
        let service = PowerTimerService(notifications: warnings, history: UsageHistory(defaults: defaults),
            defaults: defaults, now: { clock }, execute: { _ in executions += 1 })
        service.start(action: .sleep, seconds: 60)
        service.cancel(); clock = clock.addingTimeInterval(61); service.tick()
        await Task.yield()
        XCTAssertEqual(executions, 0)
        XCTAssertNil(defaults.data(forKey: "pendingPowerPlan"))
    }
    @MainActor
    func testExecutionFailureIsVisibleAndNotRetried() async {
        let defaults = UserDefaults(suiteName: "SelaTests-" + UUID().uuidString)!
        let warnings = WarningSpy()
        var clock = Date(timeIntervalSince1970: 1000)
        var executions = 0
        let service = PowerTimerService(notifications: warnings, history: UsageHistory(defaults: defaults),
            defaults: defaults, now: { clock }, execute: { _ in
                executions += 1
                throw CommandFailure(message: "Test denied")
            })
        service.start(action: .restart, seconds: 60)
        clock = clock.addingTimeInterval(61); service.tick()
        for _ in 0..<10 { await Task.yield() }
        service.tick()
        XCTAssertEqual(executions, 1)
        XCTAssertEqual(warnings.failures, ["Test denied"])
        XCTAssertTrue(service.message?.contains("Test denied") == true)
        XCTAssertFalse(service.executing)
    }
}
