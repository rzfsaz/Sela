import XCTest
import Foundation
import Darwin
@testable import SelaCore

final class TimerPlanTests: XCTestCase {
    let now = Date(timeIntervalSince1970: 1_000_000)
    func testCountdownUsesDeadlineInsteadOfTickCount() {
        let plan = TimerPlan(action: .sleep, duration: 900, now: now)
        XCTAssertEqual(plan.remaining(at: now.addingTimeInterval(137)), 763)
        XCTAssertEqual(plan.remaining(at: now.addingTimeInterval(1000)), 0)
    }
    func testPostponeAddsExactlyTenMinutes() {
        var plan = TimerPlan(action: .shutdown, duration: 900, now: now)
        plan.postpone(at: now.addingTimeInterval(300))
        XCTAssertEqual(plan.remaining(at: now.addingTimeInterval(300)), 1200)
        XCTAssertEqual(plan.duration, 1500)
    }
    func testPostponeExpiredPlanStartsFromNow() {
        var plan = TimerPlan(action: .sleep, duration: 60, now: now)
        plan.postpone(at: now.addingTimeInterval(90))
        XCTAssertEqual(plan.remaining(at: now.addingTimeInterval(90)), 600)
    }
    func testWarningsAreFiveAndOneMinutesBeforeDeadline() {
        let delays = TimerPlan(action: .restart, duration: 900, now: now).warningDelays(at: now)
        XCTAssertEqual(delays.map(\.minutes), [5, 1])
        XCTAssertEqual(delays.map(\.delay), [600, 840])
    }
    func testShortTimerDoesNotSchedulePastWarnings() {
        let plan = TimerPlan(action: .logout, duration: 120, now: now)
        XCTAssertEqual(plan.warningDelays(at: now).map(\.minutes), [1])
        XCTAssertTrue(plan.warningDelays(at: now.addingTimeInterval(70)).isEmpty)
    }
    func testDurationIsBounded() {
        XCTAssertEqual(TimerPlan(action: .sleep, duration: -1, now: now).duration, 60)
        XCTAssertEqual(TimerPlan(action: .sleep, duration: 1_000_000, now: now).duration, 86_400)
    }
    func testPersistenceRoundTrip() throws {
        let plan = TimerPlan(action: .logout, duration: 5400, now: now)
        XCTAssertEqual(try JSONDecoder().decode(TimerPlan.self, from: JSONEncoder().encode(plan)), plan)
    }
    func testPowerCommandsAreFixedAndNeverForceKillApps() {
        XCTAssertEqual(PowerAction.allCases.count, 4)
        XCTAssertEqual(PowerAction.shutdown.appleScript, "tell application \"System Events\" to shut down")
        XCTAssertTrue(PowerAction.allCases.allSatisfy { !$0.appleScript.contains("sudo") })
    }
    func testCountdownFormattingAndRounding() {
        XCTAssertEqual(DisplayFormat.countdown(59.1), "01:00")
        XCTAssertEqual(DisplayFormat.countdown(3661), "1:01:01")
        XCTAssertEqual(DisplayFormat.countdown(-1), "00:00")
    }
    func testGreetingsAtBoundaries() {
        XCTAssertEqual(DisplayFormat.greeting(hour: 5), "Selamat pagi")
        XCTAssertEqual(DisplayFormat.greeting(hour: 11), "Selamat siang")
        XCTAssertEqual(DisplayFormat.greeting(hour: 15), "Selamat sore")
        XCTAssertEqual(DisplayFormat.greeting(hour: 18), "Selamat malam")
        XCTAssertEqual(DisplayFormat.greeting(hour: 0), "Selamat malam")
    }
}

final class NetworkTests: XCTestCase {
    func testRatesUseActualElapsedTime() {
        let rates = NetworkCounters(received: 700, sent: 300).rates(since: .init(received: 100, sent: 100), elapsed: 2)
        XCTAssertEqual(rates.download, 300); XCTAssertEqual(rates.upload, 100)
    }
    func testCounterResetDoesNotUnderflow() {
        let rates = NetworkCounters(received: 1, sent: 1).rates(since: .init(received: 100, sent: 100), elapsed: 1)
        XCTAssertEqual(rates.download, 0); XCTAssertEqual(rates.upload, 0)
    }
    func testZeroElapsedDoesNotDivideByZero() {
        XCTAssertEqual(NetworkCounters(received: 100, sent: 100).rates(since: .init(received: 0, sent: 0), elapsed: 0).download, 0)
    }
}

final class CleanerTests: XCTestCase {
    private var directory: URL!
    override func setUpWithError() throws {
        let resolved = try XCTUnwrap(realpath(FileManager.default.temporaryDirectory.path, nil))
        defer { free(resolved) }
        directory = URL(fileURLWithPath: String(cString: resolved), isDirectory: true).appendingPathComponent("SelaTests-" + UUID().uuidString)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
    }
    override func tearDownWithError() throws { try FileManager.default.removeItem(at: directory) }
    private func file(_ name: String, old: Bool = true) throws -> URL {
        let url = directory.appendingPathComponent(name)
        try FileManager.default.createDirectory(at: url.deletingLastPathComponent(), withIntermediateDirectories: true)
        try Data(repeating: 65, count: 8192).write(to: url)
        if old { try FileManager.default.setAttributes([.modificationDate: Date().addingTimeInterval(-8 * 86400)], ofItemAtPath: url.path) }
        return url
    }
    func testOnlyOldCachesAreSelected() throws {
        let old = try file("old.cache")
        _ = try file("new.cache", old: false)
        XCTAssertEqual(SafeCleaner.scan(roots: [(.caches, directory)]).files.map(\.url), [old])
    }
    func testTrashAllowsRecentFiles() throws {
        _ = try file("recent", old: false)
        XCTAssertEqual(SafeCleaner.scan(roots: [(.trash, directory)]).files.count, 1)
    }
    func testSymlinksAreNeverSelectedOrFollowed() throws {
        let target = try file("target")
        try FileManager.default.createSymbolicLink(at: directory.appendingPathComponent("alias"), withDestinationURL: target)
        try FileManager.default.createSymbolicLink(at: directory.appendingPathComponent("folderAlias"), withDestinationURL: directory)
        XCTAssertEqual(SafeCleaner.scan(roots: [(.caches, directory)]).files.count, 1)
    }
    func testChangedFileIsSkipped() throws {
        let target = try file("changing")
        let snapshot = SafeCleaner.scan(roots: [(.caches, directory)])
        try Data("new contents".utf8).write(to: target)
        let result = SafeCleaner.delete(snapshot.files)
        XCTAssertEqual(result.deleted, 0); XCTAssertEqual(result.skipped, 1)
        XCTAssertTrue(FileManager.default.fileExists(atPath: target.path))
    }
    func testReplacementInodeIsSkipped() throws {
        let target = try file("replacement")
        let snapshot = SafeCleaner.scan(roots: [(.caches, directory)])
        try FileManager.default.moveItem(at: target, to: directory.appendingPathComponent("moved"))
        _ = try file("replacement")
        XCTAssertEqual(SafeCleaner.delete(snapshot.files).skipped, 1)
        XCTAssertTrue(FileManager.default.fileExists(atPath: target.path))
    }
    func testApprovedUnchangedFileIsDeleted() throws {
        let target = try file("approved")
        let snapshot = SafeCleaner.scan(roots: [(.caches, directory)])
        let result = SafeCleaner.delete(snapshot.files)
        XCTAssertEqual(result.deleted, 1); XCTAssertGreaterThan(result.freed, 0)
        XCTAssertFalse(FileManager.default.fileExists(atPath: target.path))
    }
    func testAncestorReplacedBySymlinkIsSkipped() throws {
        _ = try file("nested/approved")
        let snapshot = SafeCleaner.scan(roots: [(.caches, directory)])
        try FileManager.default.moveItem(at: directory.appendingPathComponent("nested"), to: directory.appendingPathComponent("moved"))
        try FileManager.default.createSymbolicLink(at: directory.appendingPathComponent("nested"), withDestinationURL: directory.appendingPathComponent("moved"))
        XCTAssertEqual(SafeCleaner.delete(snapshot.files).skipped, 1)
        XCTAssertTrue(FileManager.default.fileExists(atPath: directory.appendingPathComponent("moved/approved").path))
    }
    func testScanLimitIsExplicit() throws {
        _ = try file("one"); _ = try file("two")
        let result = SafeCleaner.scan(roots: [(.caches, directory)], limit: 1)
        XCTAssertEqual(result.files.count, 1); XCTAssertFalse(result.warnings.isEmpty)
    }
    func testHardLinkedFilesAreExcluded() throws {
        let target = try file("original")
        try FileManager.default.linkItem(at: target, to: directory.appendingPathComponent("hardlink"))
        XCTAssertTrue(SafeCleaner.scan(roots: [(.caches, directory)]).files.isEmpty)
    }
}
