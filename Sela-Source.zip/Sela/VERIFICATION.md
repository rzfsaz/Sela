# Hasil verifikasi

- Release build: **berhasil**, Xcode 26.6 / Swift 6.3.3, language mode Swift 5.
- Debug build: **berhasil**.
- XCTest: **28 pengujian lulus**, 0 kegagalan.
- Arsitektur binary: **arm64**.
- Minimum deployment: **macOS 14.0**.
- Agent mode: **LSUIElement = true**.
- Code signing: **ad-hoc valid**, pemeriksaan `codesign --verify --deep --strict` lulus.
- Notarization: **belum dilakukan**.
- Preview: **18 render offscreen**, 8 modul + greeting, Light/Dark.
- Runtime smoke check: proses aplikasi berhasil diluncurkan; tidak memicu timer atau aksi daya.
- UI langsung: **lulus untuk alur yang diuji** — buka dari Finder, tutup panel, buka ulang, timer Sleep/Shutdown, tunda, cancel, dan pemeriksaan akses System Events.
- Target M3/macOS 14: dikonfigurasi dan kompatibel secara deployment; **belum diuji pada kombinasi hardware/OS tersebut secara langsung**.

Pengujian Cleaner hanya memakai folder sementara berisi file fixture. Tidak ada cache, log, atau Trash pengguna yang dihapus. Aksi daya saat deadline, paste otomatis ke app lain, dan toggle DND tidak dijalankan sebagai bagian validasi. Semua timer uji dibatalkan sebelum deadline.

## Perbaikan pembukaan aplikasi

Launch/reopen dari Applications kini menampilkan panel transient tanpa Dock atau WindowGroup. MenuBarExtra tetap menjadi scene utama. Ditambahkan file lock dan notifikasi lokal antarproses untuk mencegah instance ganda. Release arm64 berhasil dibangun ulang; status panel saat launch dicatat dari NSPanel aplikasi sendiri.

## Perbaikan timer dan instalasi tunggal

Masalah direproduksi lewat UI: Jadwalkan menjadi nonaktif karena menunggu jawaban izin notifikasi sebelum membuat timer. Setelah perbaikan, Sleep dan Shutdown langsung menampilkan 30:00; tunda mengubah sisa waktu menjadi sekitar 39:54; Cancel kembali ke pilihan jadwal. Pemeriksaan versi System Events dari aplikasi terpasang berhasil.

Satu aplikasi dipertahankan di `/Applications/Sela.app`. Salinan build dan arsip binary dipindahkan ke Trash, dan entri Launch Services untuk build dibatalkan. Source ZIP hanya berisi source, dokumentasi, dan preview.

## Regresi panel dan konfirmasi

Konfirmasi timer kini berada di dalam panel, tanpa alert modal. Draft disimpan di service. Konten utama tetap terpasang ketika greeting muncul, dan MenuBarExtra serta pembukaan Applications diarahkan ke satu panel persisten. Dua tes tambahan mencakup konfirmasi draft dan pembatalannya. Build Release terbaru berhasil. Jalur klik ikon menu bar belum diverifikasi langsung melalui otomatisasi UI.
