// swift-tools-version: 5.9
import PackageDescription
let package = Package(
    name: "Sela",
    platforms: [.macOS(.v14)],
    products: [.executable(name: "Sela", targets: ["Sela"])],
    targets: [
        .target(name: "SelaCore"),
        .executableTarget(name: "Sela", dependencies: ["SelaCore"]),
        .testTarget(name: "SelaCoreTests", dependencies: ["SelaCore"]),
        .testTarget(name: "SelaServiceTests", dependencies: ["Sela", "SelaCore"])
    ]
)
