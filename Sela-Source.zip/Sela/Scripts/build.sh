#!/bin/zsh
set -euo pipefail
PROJECT_DIR="${0:A:h:h}"
BUILD_DIR="${SELA_BUILD_DIR:-$PROJECT_DIR/build.noindex}"
xcodebuild -project "$PROJECT_DIR/Sela.xcodeproj" -scheme Sela -configuration Release -derivedDataPath "$BUILD_DIR" -destination 'platform=macOS,arch=arm64' build
print "Aplikasi siap: $BUILD_DIR/Build/Products/Release/Sela.app"
