#!/bin/zsh
set -euo pipefail
PROJECT_DIR="${0:A:h:h}"
swift test --package-path "$PROJECT_DIR" --scratch-path "${SELA_TEST_DIR:-$PROJECT_DIR/.build}"
